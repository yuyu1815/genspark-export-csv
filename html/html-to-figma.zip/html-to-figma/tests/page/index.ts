import { htmlToFigma } from '../../src/browser/html-to-figma';
// @ts-ignore
window.__htmlToFigma = htmlToFigma;
