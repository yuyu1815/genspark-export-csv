import { MetaTextNode, PlainLayerNode } from '../types';
import {
    fastClone,
    parseUnits,
    getRgb,
    defaultPlaceholderColor,
} from '../utils';
import { getLineHeight, isHidden } from './dom-utils';
import {context, getCachedComputedStyle} from './utils';

export const textToFigma = (node: Element, { fromTextInput = false } = {}, useAutoLayout=false) => {
    const textValue = (
        node.textContent ||
        (node as HTMLInputElement).value ||
        (node as HTMLInputElement).placeholder
    )?.trim();

    if (!textValue) return;

    const parent = node.parentElement as Element;

    if (isHidden(parent)) {
        return;
    }
    const computedStyles = getCachedComputedStyle(fromTextInput ? node : parent);
    const range = context.document.createRange();
    range.selectNode(node);
    const rect = fastClone(range.getBoundingClientRect());

    const lineHeight = getLineHeight(node as HTMLElement, computedStyles);

    range.detach();
    if (lineHeight && lineHeight.value && rect.height < lineHeight.value) {
        const delta = lineHeight.value - rect.height;
        rect.top -= delta / 2;
        rect.height = lineHeight.value;
    }
    if (rect.height < 1 || rect.width < 1) {
        return;
    }
    let x = Math.round(rect.left);
    let y = Math.round(rect.top);
    let width = Math.round(rect.width);
    let height = Math.round(rect.height);

    if (fromTextInput) {
        const borderLeftWidth =
            parseUnits(computedStyles.borderLeftWidth)?.value || 0;
        const borderRightWidth =
            parseUnits(computedStyles.borderRightWidth)?.value || 0;

        const paddingLeft = parseUnits(computedStyles.paddingLeft)?.value || 0;
        const paddingRight =
            parseUnits(computedStyles.paddingRight)?.value || 0;
        const paddingTop = parseUnits(computedStyles.paddingTop)?.value || 0;
        const paddingBottom =
            parseUnits(computedStyles.paddingBottom)?.value || 0;

        x = x + borderLeftWidth + (fromTextInput ? paddingLeft : 0);
        y = y + paddingTop;
        width = width - borderRightWidth - paddingRight;
        height = height - paddingTop - paddingBottom;
    }

    const fontWeightMap: { [key: string]: number } = {
        normal: 400,
        bold: 700,
        bolder: 900,
        lighter: 100,
    };

    let fontWeight: string | number = computedStyles.fontWeight;
    if (isNaN(Number(fontWeight))) {
        fontWeight = fontWeightMap[fontWeight] || '400'; // Default to 400 if the value is not in the map
    }

    const textNode = {
        x,
        y,
        width,
        height,
        ref: node,
        type: 'TEXT',
        characters: textValue?.replace(/\s+/g, ' ') || '',
        fontWeight,
    } as MetaTextNode;

    const fills: SolidPaint[] = [];
    let rgb = getRgb(computedStyles.color);
    const isPlaceholder =
        fromTextInput &&
        !(node as HTMLInputElement).value &&
        (node as HTMLInputElement).placeholder;
    rgb = isPlaceholder ? defaultPlaceholderColor : rgb;

    if (rgb) {
        fills.push({
            type: 'SOLID',
            color: {
                r: rgb.r,
                g: rgb.g,
                b: rgb.b,
            },
            blendMode: 'NORMAL',
            visible: true,
            opacity: rgb.a || 1,
        } as SolidPaint);
    }

    if (fills.length) {
        textNode.fills = fills;
    }
    const letterSpacing = parseUnits(computedStyles.letterSpacing);
    if (letterSpacing) {
        textNode.letterSpacing = letterSpacing;
    }
    if (lineHeight) {
        textNode.lineHeight = lineHeight;
    }

    const { textTransform } = computedStyles;
    switch (textTransform) {
        case 'uppercase': {
            textNode.textCase = 'UPPER';
            break;
        }
        case 'lowercase': {
            textNode.textCase = 'LOWER';
            break;
        }
        case 'capitalize': {
            textNode.textCase = 'TITLE';
            break;
        }
    }

    const fontSize = parseUnits(computedStyles.fontSize);
    if (fontSize) {
        textNode.fontSize = Math.round(fontSize.value);
    }
    if (computedStyles.fontFamily) {
        // const font = computedStyles.fontFamily.split(/\s*,\s*/);
        textNode.fontFamily = computedStyles.fontFamily;
    }

    if (computedStyles.textDecoration) {
        if (
            computedStyles.textDecoration === 'underline' ||
            computedStyles.textDecoration === 'strikethrough'
        ) {
            textNode.textDecoration =
                computedStyles.textDecoration.toUpperCase() as any;
        }
    }
    if (computedStyles.textAlign) {
        if (
            ['left', 'center', 'right', 'justified'].includes(
                computedStyles.textAlign,
            )
        ) {
            textNode.textAlignHorizontal =
                computedStyles.textAlign.toUpperCase() as any;
        }
    }

    // Handle text-shadow
    if (computedStyles.textShadow && computedStyles.textShadow !== 'none') {
        const effects: Effect[] = textNode.effects || [];

        // Parse text-shadow
        // Format: h-shadow v-shadow blur color, h-shadow v-shadow blur color, ...
        const textShadows = computedStyles.textShadow.split(',').map(s => s.trim());

        for (const shadow of textShadows) {
            // Split the shadow into its components
            const parts = shadow.split(' ').filter(p => p.trim() !== '');

            // Need at least 3 parts: h-shadow, v-shadow, and color
            if (parts.length >= 3) {
                // The color can be at the beginning or the end
                let hShadow, vShadow, blur, color;

                // Check if the first part is a color
                if (parts[0].includes('rgb') || parts[0].includes('#') || parts[0].includes('hsl')) {
                    color = parts[0];
                    hShadow = parts[1];
                    vShadow = parts[2];
                    blur = parts.length > 3 ? parts[3] : '0px';
                } else {
                    // Color is at the end
                    hShadow = parts[0];
                    vShadow = parts[1];
                    blur = parts.length > 3 ? parts[2] : '0px';
                    color = parts[parts.length - 1];
                }

                // Parse values
                const hOffset = parseUnits(hShadow)?.value || 0;
                const vOffset = parseUnits(vShadow)?.value || 0;
                const blurRadius = parseUnits(blur)?.value || 0;
                const shadowColor = getRgb(color);

                if (shadowColor) {
                    effects.push({
                        type: 'DROP_SHADOW',
                        color: {
                            r: shadowColor.r,
                            g: shadowColor.g,
                            b: shadowColor.b,
                            a: shadowColor.a || 1,
                        },
                        offset: {x: hOffset, y: vOffset},
                        radius: blurRadius,
                        spread: 0, // Text shadows don't have spread
                        visible: true,
                        blendMode: 'NORMAL',
                    } as ShadowEffect);
                }
            }
        }

        if (effects.length > 0) {
            textNode.effects = effects;
        }
    }

    // console.log('useAutoLayout', useAutoLayout);
    // if (useAutoLayout) {
    //     console.log('useAutoLayout', useAutoLayout);
    //     textNode.isAutoLayout = true;
    //     textNode.layoutSizingHorizontal="FILL";
    //     textNode.layoutSizingVertical="FILL";
    //     textNode.counterAxisAlignItems="MAX";
    //     (textNode as any).primaryAxisAlignItems="MAX";
    //     (textNode as any).layoutMode = "VERTICAL";
    // }

    return textNode;
};
