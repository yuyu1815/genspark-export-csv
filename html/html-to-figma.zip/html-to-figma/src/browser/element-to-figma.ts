import {
    isHidden,
    getBoundingClientRect,
    getUrl,
    prepareUrl,
    isElemType,
    ElemTypes,
    processImages,
} from './dom-utils';
import { getRgb, parseUnits, parseBoxShadowValues, getOpacity } from '../utils';
import {
    MetaLayerNode,
    SvgNode,
    WithMeta,
} from '../types';
import {context, parseGradient, replaceSvgFill, getCachedComputedStyle} from './utils';
import { textToFigma } from './text-to-figma';
import { getBorder, getBorderPin } from './border';
import { addConstraintToLayer } from './add-constraints';
import { setAutoLayoutProps } from './addAutoLayoutProps';

export const elementToFigma = async (
    el: Element,
    pseudo?: string,
    useAutoLayout = false,
): Promise<MetaLayerNode | undefined> => {
    if (el.nodeType === Node.TEXT_NODE) {
        return textToFigma(el, {}, useAutoLayout);
    }
    if (el.nodeType !== Node.ELEMENT_NODE) {
        return;
    }

    if (
        el.nodeType !== Node.ELEMENT_NODE ||
        isHidden(el, pseudo) ||
        isElemType(el, ElemTypes.SubSVG)
    ) {
        return;
    }

    if (el.parentElement && isElemType(el, ElemTypes.Picture)) {
        return;
    }

    const computedStyle = getCachedComputedStyle(el, pseudo);

    if (isElemType(el, ElemTypes.SVG)) {
        const rect = el.getBoundingClientRect();
        const fill = computedStyle.fill;

        return {
            type: 'SVG',
            ref: el,
            // add FILL to SVG to get right color in figma
            svg: replaceSvgFill(el.outerHTML, fill),
            x: Math.round(rect.left),
            y: Math.round(rect.top),
            width: Math.round(rect.width),
            height: Math.round(rect.height),
        } as WithMeta<SvgNode>;
    }

    const rect = getBoundingClientRect(el, pseudo);

    if (rect.width < 1 || rect.height < 1) {
        return;
    }

    const fills: Paint[] = [];
    const color = getRgb(computedStyle.backgroundColor);

    if (color) {
        fills.push({
            type: 'SOLID',
            color: {
                r: color.r,
                g: color.g,
                b: color.b,
            },
            opacity: color.a || 1,
        } as SolidPaint);
    }

    const overflowHidden = computedStyle.overflow !== 'visible';
    const rectNode = {
        type: 'FRAME',
        ref: el,
        x: Math.round(rect.left),
        y: Math.round(rect.top),
        width: Math.round(rect.width),
        height: Math.round(rect.height),
        clipsContent: !!overflowHidden,
        fills: fills as any,
        children: [],
        opacity: getOpacity(computedStyle),
    } as WithMeta<FrameNode>;

    const zIndex = Number(computedStyle.zIndex);
    if (isFinite(zIndex)) {
        rectNode.zIndex = zIndex;
    }

    const gradient = parseGradient(computedStyle.backgroundImage);

    if (gradient) {
        // Removed console.warn for performance improvement
        const fills: Paint[] = Array.isArray(rectNode.fills)
            ? [...rectNode.fills]
            : [];
        if (gradient.type === 'GRADIENT_LINEAR') {
            fills.push({
                type: 'GRADIENT_LINEAR',
                gradientStops: gradient.colorStops
                    .map((stop) => {
                        if (stop.color) {
                            return {
                                color: {
                                    r: stop.color.r,
                                    g: stop.color.g,
                                    b: stop.color.b,
                                    a:
                                        stop.color.a !== undefined
                                            ? stop.color.a
                                            : 1,
                                },
                                position: stop.position,
                            };
                        }
                    })
                    .filter(Boolean) as ColorStop[],
                gradientTransform: [
                    [
                        Math.cos(gradient.angle),
                        Math.sin(gradient.angle),
                        gradient.transform.x,
                    ],
                    [
                        -Math.sin(gradient.angle),
                        Math.cos(gradient.angle),
                        gradient.transform.y,
                    ],
                ],
            });
        } else if (gradient.type === 'GRADIENT_RADIAL') {
            fills.push({
                type: 'GRADIENT_RADIAL',
                gradientStops: gradient.colorStops
                    .map((stop) => {
                        if (stop.color) {
                            return {
                                color: {
                                    r: stop.color.r,
                                    g: stop.color.g,
                                    b: stop.color.b,
                                    a:
                                        stop.color.a !== undefined
                                            ? stop.color.a
                                            : 1,
                                },
                                position: stop.position,
                            };
                        }
                    })
                    .filter(Boolean) as ColorStop[],
                gradientTransform: [
                    [1, 0, gradient.transform.x],
                    [0, 1, gradient.transform.y],
                ],
            });
        }
        // Removed console.warn for performance improvement
        rectNode.fills = [...(rectNode.fills as Paint[]), ...fills];
    }

    const stroke = getBorder(computedStyle);

    if (stroke) {
        rectNode.strokes = stroke.strokes as SolidPaint[];
        rectNode.strokeWeight = stroke.strokeWeight;
    } else {
        rectNode.borders = getBorderPin(rect, computedStyle);
    }

    if (
        computedStyle.backgroundImage &&
        computedStyle.backgroundImage !== 'none'
    ) {
        const urlMatch = computedStyle.backgroundImage.match(
            /url\(['"]?(.*?)['"]?\)/,
        );
        const url = urlMatch && urlMatch[1];

        if (url) {
            // Handle background size
            let scaleMode: 'FILL' | 'FIT' | 'TILE' | 'STRETCH' = 'FILL';

            // Parse background-size
            if (computedStyle.backgroundSize) {
                if (computedStyle.backgroundSize === 'contain') {
                    scaleMode = 'FIT';
                } else if (computedStyle.backgroundSize === 'cover') {
                    scaleMode = 'FILL';
                } else if (computedStyle.backgroundSize === 'repeat') {
                    scaleMode = 'TILE';
                } else if (computedStyle.backgroundSize.includes('100%')) {
                    scaleMode = 'STRETCH';
                }
            }

            // Create the image fill
            const imageFill: ImagePaint = {
                url: prepareUrl(url),
                type: 'IMAGE',
                scaleMode,
                imageHash: '',
            };

            // Handle background position
            if (computedStyle.backgroundPosition && scaleMode !== 'TILE') {
                // Parse background-position
                const position = computedStyle.backgroundPosition.split(' ');

                // Convert position to Figma's imageTransform
                // This is a simplified implementation - Figma's imageTransform is a 2D matrix
                // that requires more complex calculations for precise positioning
                if (position.length >= 2) {
                    const xPos = position[0];
                    const yPos = position[1];

                    // Set default scaling (no scaling)
                    const scaleX = 1;
                    const scaleY = 1;

                    // Calculate translation based on position keywords
                    let translateX = 0;
                    let translateY = 0;

                    // Handle X position
                    if (xPos === 'left') translateX = 0;
                    else if (xPos === 'center') translateX = 0.5;
                    else if (xPos === 'right') translateX = 1;
                    else if (xPos.includes('%')) {
                        translateX = parseFloat(xPos) / 100;
                    }

                    // Handle Y position
                    if (yPos === 'top') translateY = 0;
                    else if (yPos === 'center') translateY = 0.5;
                    else if (yPos === 'bottom') translateY = 1;
                    else if (yPos.includes('%')) {
                        translateY = parseFloat(yPos) / 100;
                    }

                    // Set the imageTransform matrix
                    // Format: [[scaleX, 0, translateX], [0, scaleY, translateY]]
                    imageFill.imageTransform = [
                        [scaleX, 0, translateX],
                        [0, scaleY, translateY]
                    ];
                }
            }

            fills.push(imageFill);
        }
    }
    // if (isElemType(el, ElemTypes.SVG)) {
    //     const url = `data:image/svg+xml,${encodeURIComponent(
    //         el.outerHTML.replace(/\s+/g, ' ')
    //     )}`;
    //     if (url) {
    //         fills.push({
    //             url,
    //             type: 'IMAGE',
    //             // TODO: object fit, position
    //             scaleMode: 'FILL',
    //             imageHash: null,
    //         } as ImagePaint);
    //     }
    // }
    if (isElemType(el, ElemTypes.Image)) {
        const url = (el as HTMLImageElement).src;
        if (url) {
            fills.push({
                url,
                type: 'IMAGE',
                // TODO: object fit, position
                scaleMode:
                    computedStyle.objectFit === 'contain' ? 'FIT' : 'FILL',
                imageHash: '',
            } as ImagePaint);
        }
    }

    if (isElemType(el, ElemTypes.Picture)) {
        const firstSource = el.querySelector('source');
        if (firstSource) {
            const src = getUrl(firstSource.srcset.split(/[,\s]+/g)[0]);
            // TODO: if not absolute
            if (src) {
                fills.push({
                    url: src,
                    type: 'IMAGE',
                    // TODO: object fit, position
                    scaleMode:
                        computedStyle.objectFit === 'contain' ? 'FIT' : 'FILL',
                    imageHash: '',
                } as ImagePaint);
            }
        }
    }
    if (isElemType(el, ElemTypes.Video)) {
        const url = (el as HTMLVideoElement).poster;
        if (url) {
            fills.push({
                url,
                type: 'IMAGE',
                // TODO: object fit, position
                scaleMode:
                    computedStyle.objectFit === 'contain' ? 'FIT' : 'FILL',
                imageHash: '',
            } as ImagePaint);
        }
    }

    await processImages(rectNode as any);

    // Handle box-shadow
    if (computedStyle.boxShadow && computedStyle.boxShadow !== 'none') {
        const parsed = parseBoxShadowValues(computedStyle.boxShadow);
        const hasShadowSpread =
            parsed.findIndex(({ spreadRadius }) => Boolean(spreadRadius)) !==
            -1;
        // figma requires clipsContent=true, without spreadRadius wont be applied
        if (hasShadowSpread) {
            rectNode.clipsContent = true;
        }
        rectNode.effects = parsed.map((shadow) => ({
            color: shadow.color,
            type: 'DROP_SHADOW',
            radius: shadow.blurRadius,
            spread: shadow.spreadRadius,
            blendMode: 'NORMAL',
            visible: true,
            offset: {
                x: shadow.offsetX,
                y: shadow.offsetY,
            },
            //@ts-expect-error
        })) as ShadowEffect[];
    }

    // Handle CSS filters
    if (computedStyle.filter && computedStyle.filter !== 'none') {
        const effects = rectNode.effects || [];

        // Parse filter string
        const filterString = computedStyle.filter;
        const filterRegex = /(\w+)\(([^)]+)\)/g;
        let match;

        while ((match = filterRegex.exec(filterString)) !== null) {
            const [, filterName, filterValue] = match;

            switch (filterName) {
                case 'blur':
                    // Extract blur radius (remove 'px' and convert to number)
                    const blurRadius = parseFloat(filterValue.replace('px', ''));
                    if (!isNaN(blurRadius)) {
                        effects.push({
                            type: 'LAYER_BLUR',
                            radius: blurRadius,
                            visible: true,
                        } as LayerBlurEffect);
                    }
                    break;

                case 'brightness':
                    // Brightness is handled differently in Figma, we can approximate with opacity
                    const brightness = parseFloat(filterValue);
                    if (!isNaN(brightness)) {
                        // Adjust opacity based on brightness
                        rectNode.opacity = (rectNode.opacity || 1) * Math.min(brightness, 1);
                    }
                    break;

                case 'contrast':
                case 'grayscale':
                case 'hue-rotate':
                case 'invert':
                case 'saturate':
                case 'sepia':
                    // These filters don't have direct equivalents in Figma
                    // We could potentially use image fills with adjusted properties
                    // but that's beyond the scope of this implementation
                    console.warn(`CSS filter '${filterName}' is not fully supported in Figma conversion`);
                    break;

                case 'drop-shadow':
                    // Extract shadow values (color, offsetX, offsetY, blurRadius)
                    const shadowValues = filterValue.split(' ').map(v => v.trim());
                    if (shadowValues.length >= 3) {
                        const color = getRgb(shadowValues[0]);
                        const offsetX = parseFloat(shadowValues[1].replace('px', ''));
                        const offsetY = parseFloat(shadowValues[2].replace('px', ''));
                        const shadowBlurRadius = shadowValues.length > 3 ?
                            parseFloat(shadowValues[3].replace('px', '')) : 0;

                        if (color && !isNaN(offsetX) && !isNaN(offsetY)) {
                            effects.push({
                                type: 'DROP_SHADOW',
                                color: {
                                    r: color.r,
                                    g: color.g,
                                    b: color.b,
                                    a: color.a || 1,
                                },
                                offset: {x: offsetX, y: offsetY},
                                radius: shadowBlurRadius,
                                spread: 0,
                                visible: true,
                                blendMode: 'NORMAL',
                            } as ShadowEffect);
                        }
                    }
                    break;
            }
        }

        if (effects.length > 0) {
            rectNode.effects = effects;
        }
    }

    const borderTopLeftRadius = parseUnits(
        computedStyle.borderTopLeftRadius,
        rect.height,
    );
    if (borderTopLeftRadius) {
        rectNode.topLeftRadius = borderTopLeftRadius.value;
    }
    const borderTopRightRadius = parseUnits(
        computedStyle.borderTopRightRadius,
        rect.height,
    );
    if (borderTopRightRadius) {
        rectNode.topRightRadius = borderTopRightRadius.value;
    }
    const borderBottomRightRadius = parseUnits(
        computedStyle.borderBottomRightRadius,
        rect.height,
    );
    if (borderBottomRightRadius) {
        rectNode.bottomRightRadius = borderBottomRightRadius.value;
    }
    const borderBottomLeftRadius = parseUnits(
        computedStyle.borderBottomLeftRadius,
        rect.height,
    );
    if (borderBottomLeftRadius) {
        rectNode.bottomLeftRadius = borderBottomLeftRadius.value;
    }

    const result = rectNode;

    if (!pseudo && getCachedComputedStyle(el, 'before').content !== 'none') {
        result.before = (await elementToFigma(
            el,
            'before',
        )) as WithMeta<FrameNode>;

        if (result.before) {
            addConstraintToLayer(result.before, el as HTMLElement, 'before');
            result.before.name = '::before';
        }
    }

    if (!pseudo && getCachedComputedStyle(el, 'after').content !== 'none') {
        result.after = (await elementToFigma(
            el,
            'after',
        )) as WithMeta<FrameNode>;
        if (result.after) {
            addConstraintToLayer(result.after, el as HTMLElement, 'after');
            result.after.name = '::after';
        }
    }

    if (isElemType(el, ElemTypes.Input) || isElemType(el, ElemTypes.Textarea)) {
        result.textValue = textToFigma(el, { fromTextInput: true });
    }


    return result;
};
